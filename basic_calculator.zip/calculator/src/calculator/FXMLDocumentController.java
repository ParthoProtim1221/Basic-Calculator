/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 *
 * @author Acer
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private Label index;
    int number1 =0;
    int number2 =0;
    char sign= '.';
    int result = 0;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        index.setText("   Welcome to My Calculator ... ");
        // TODO
    }    

    @FXML
    private void sevenButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+7;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+7;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void eightButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+8;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+8;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void nineButtonOnClick(ActionEvent event) {
        if(sign == '.'){
            number1 = number1*10+9;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+9;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void sumButtonOnClick(ActionEvent event) {
        sign ='+';
        index.setText(Integer.toString(number1)+sign);
    }

    @FXML
    private void fourButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+4;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+4;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void fiveButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+5;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+5;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void sixButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+6;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+6;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void negativeButtonONClick(ActionEvent event) {
        sign ='-';
        index.setText(Integer.toString(number1)+sign);
    }

    @FXML
    private void oneButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+1;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+1;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void twoButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+2;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+2;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void threeButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+3;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+3;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void multiButtonOnClick(ActionEvent event) {
        sign ='*';
        index.setText(Integer.toString(number1)+sign);
    }

    @FXML
    private void zeroButtonOnClick(ActionEvent event) {
        if(sign == '.')
        {
            number1 = number1*10+0;
            index.setText(Integer.toString(number1));
        }
        else 
        {
            number2 = number2*10+0;
            index.setText(Integer.toString(number1)+sign+Integer.toString(number2));
        }
    }

    @FXML
    private void cButtonOnCllick(ActionEvent event) {
        result = 0;
        number1=0;
        number2=0;
        sign ='.';
        index.setText("");
    }

    @FXML
    private void equalButtonOnClick(ActionEvent event) {
        if(sign=='+')
        {
            result = number1+number2;
            index.setText(Integer.toString(result));
        }
        else if (sign =='-')
        {
            result = number1-number2;
            index.setText(Integer.toString(result));
        }
        else if(sign =='*')
        {
            result = number1*number2;
            index.setText(Integer.toString(result));
        }
        else if (sign == '/')
        {
            float r = (float)number1 / number2;
            index.setText(Float.toString(r));
        }
        number1=0;
        number2=0;
        sign='.';
        result =0;
    }

    @FXML
    private void divButtonOnClick(ActionEvent event) {
        sign ='/';
        index.setText(Integer.toString(number1)+sign);
    }
    
}
